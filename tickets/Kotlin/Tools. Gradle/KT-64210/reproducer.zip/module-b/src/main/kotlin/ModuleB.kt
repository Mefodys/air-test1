class ModuleB
