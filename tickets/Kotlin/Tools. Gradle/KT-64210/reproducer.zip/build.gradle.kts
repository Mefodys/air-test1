allprojects {
    repositories {
        mavenCentral()
    }
}
